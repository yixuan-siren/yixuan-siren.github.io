import fs from 'node:fs';
import path from 'node:path';
import {parseHTML} from 'linkedom';

// New entries are additive: legacy pages are never rewritten or replaced.
const base = 'content/managed';
const html = value => String(value).replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;').replaceAll('"','&quot;').replaceAll("'",'&#39;');
const fail = message => { throw new Error(message); };
const required = (value, name, file) => typeof value === 'string' && value.trim() ? value.trim() : fail(`${file}: ${name} must be a nonempty string`);
const files = dir => fs.existsSync(dir) ? fs.readdirSync(dir).filter(f => f.endsWith('.json')).sort().map(f => `${dir}/${f}`) : [];
const read = (kind) => files(`${base}/${kind}`).map(file => {
  let item;
  try { item = JSON.parse(fs.readFileSync(file,'utf8')); } catch (e) { fail(`${file}: invalid JSON: ${e.message}`); }
  if (item.draft === true) return null;
  const slug = required(item.slug, 'slug', file);
  if (!/^[a-z0-9]+(?:-[a-z0-9]+)*$/.test(slug)) fail(`${file}: slug must use lowercase letters, numbers, and hyphens`);
  const title = required(item.title, 'title', file);
  const summary = required(item.summary, 'summary', file);
  const date = required(item.date, 'date', file);
  if (!/^\d{4}-\d{2}-\d{2}$/.test(date) || Number.isNaN(Date.parse(date)) || new Date(date).toISOString().slice(0,10) !== date) fail(`${file}: date must be a valid date in YYYY-MM-DD format`);
  if (!Array.isArray(item.body) || !item.body.length) fail(`${file}: body must contain at least one block`);
  if (kind === 'posts' && !['research','firmware','fun','others'].includes(item.category)) fail(`${file}: category must be research, firmware, fun, or others`);
  return {...item, slug, title, summary, date, file, kind};
}).filter(Boolean);
const uploads = `${base}/uploads`;
function picture(name, file) {
  if (!name) return '';
  if (typeof name !== 'string' || !/^[a-zA-Z0-9][a-zA-Z0-9._-]*\.(?:png|jpe?g|gif|webp)$/i.test(name)) fail(`${file}: image must be a filename in ${uploads} (png, jpg, gif, or webp)`);
  const source = `${uploads}/${name}`;
  if (!fs.existsSync(source)) fail(`${file}: image not found: ${source}`);
  fs.mkdirSync('site/assets/managed',{recursive:true});
  fs.copyFileSync(source, `site/assets/managed/${name}`);
  return `/assets/managed/${name}`;
}
function blocks(item) {
  return item.body.map((block,i) => {
    const context = `${item.file}: body block ${i+1}`;
    if (!block || typeof block !== 'object') fail(`${context}: expected an object`);
    if (block.type === 'paragraph') return `<p>${html(required(block.text,'text',context))}</p>`;
    if (block.type === 'heading') return `<h2>${html(required(block.text,'text',context))}</h2>`;
    if (block.type === 'image') {
      const src = picture(required(block.file,'file',context),context);
      const alt = required(block.alt,'alt',context);
      return `<figure><img src="${src}" alt="${html(alt)}" loading="lazy">${block.caption ? `<figcaption>${html(block.caption)}</figcaption>` : ''}</figure>`;
    }
    if (block.type === 'link') {
      const url = required(block.url,'url',context);
      if (!/^https?:\/\//i.test(url)) fail(`${context}: link must start with https:// or http://`);
      return `<p><a href="${html(url)}">${html(required(block.text,'text',context))}</a></p>`;
    }
    fail(`${context}: type must be paragraph, heading, image, or link`);
  }).join('\n');
}
const posts = read('posts');
const projects = read('portfolio');
const seen = new Set();
for (const item of [...posts,...projects]) {
  const prefix = item.kind === 'posts' ? 'post' : 'portfolio-collections/my-portfolio';
  const url = `/${prefix}/${item.slug}/`;
  if (seen.has(url)) fail(`${item.file}: duplicate slug ${item.slug}`);
  seen.add(url);
  if (item.kind === 'portfolio' && !item.cover) fail(`${item.file}: portfolio items require a cover image`);
  const cover = picture(item.cover,item.file);
  const content = blocks(item);
  for (const root of ['site','site/_mobile']) {
    const destination = `${root}${url}index.html`;
    if (fs.existsSync(destination) && !fs.readFileSync(destination,'utf8').includes('<!-- managed-content-page -->')) fail(`${item.file}: ${destination} already exists; refusing to overwrite an existing page`);
    let page = fs.readFileSync(`${base}/templates/${root.endsWith('_mobile') ? 'mobile' : 'desktop'}.html`,'utf8');
    const title = `${item.title} | Yixuan Song`;
    page = page.replace(/<title>[^<]*<\/title>/, `<title>${html(title)}</title>`)
      .replace('https://yixuan-siren.github.io/post/first-research-cruise/', `https://yixuan-siren.github.io${url}`);
    const back = item.kind === 'posts' ? ['/research-blog/','Research &amp; Updates'] : ['/portfolio/','Portfolio'];
    const article = `<!-- managed-content-page --><article class="cruise-blog-post" data-hook="post"><a class="cruise-blog-back" href="${back[0]}">${back[1]}</a><h1>${html(item.title)}</h1><p class="cruise-blog-date">Yixuan Song · ${html(item.date)}</p>${content}</article>`;
    const match = page.match(/<article class="cruise-blog-post"[\s\S]*?<\/article>/);
    if (!match) fail(`Cannot find article template in ${root}`);
    page = page.replace(match[0],article);
    fs.mkdirSync(path.dirname(destination),{recursive:true});
    fs.writeFileSync(destination,page);
  }
  item.url = url; item.coverUrl = cover;
}
function insert(file, selector, markup) {
  let source = fs.readFileSync(file,'utf8');
  source = source.replace(/<!-- managed-content-start -->[\s\S]*?<!-- managed-content-end -->/g,'');
  const {document} = parseHTML(source);
  const element = document.querySelector(selector);
  if (!element) fail(`Missing ${selector} in ${file}`);
  const opening = element.outerHTML.slice(0, element.outerHTML.indexOf('>')+1);
  if (!source.includes(opening)) fail(`Cannot locate insertion point in ${file}`);
  if (markup) source = source.replace(opening, `${opening}<!-- managed-content-start -->${markup}<!-- managed-content-end -->`);
  fs.writeFileSync(file,source);
}
const ordered = items => [...items].sort((a,b) => b.date.localeCompare(a.date) || a.title.localeCompare(b.title));
const blogCards = ordered(posts).map(p => `<article class="blog-directory-card${p.coverUrl?'':' blog-directory-card--text'}" data-hook="post" data-blog-category="${p.category}"><a href="${p.url}">${p.coverUrl?`<img src="${p.coverUrl}" alt="${html(p.coverAlt || p.title)}" loading="lazy">`:''}<div class="blog-directory-copy"><span class="blog-directory-year">${html(p.date)}</span><h2>${html(p.title)}</h2><p>${html(p.summary)}</p><span class="blog-directory-more">Read the update</span></div></a></article>`).join('');
const projectCards = ordered(projects).map(p => `<a class="item-link-wrapper" href="${p.url}" aria-label="${html(p.title)}"><div class="gallery-item-container"><div class="gallery-item-wrapper"><div class="gallery-item-content"><img src="${p.coverUrl}" alt="${html(p.coverAlt || p.title)}" style="width:100%;height:100%;object-fit:cover" loading="lazy"></div></div></div></a>`).join('');
for (const root of ['site','site/_mobile']) {
  insert(`${root}/research-blog/index.html`,'.blog-directory',blogCards);
  insert(`${root}/portfolio/index.html`,'.pro-gallery-margin-container',projectCards);
}
console.log(`Built ${posts.length} Research & Updates posts and ${projects.length} portfolio projects.`);
