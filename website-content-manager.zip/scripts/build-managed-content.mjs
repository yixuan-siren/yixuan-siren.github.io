import fs from 'node:fs';
import path from 'node:path';
import {parseHTML} from 'linkedom';

// New entries are additive: legacy pages are never rewritten or replaced.
const base = 'content/managed';
const html = value => String(value).replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;').replaceAll('"','&quot;').replaceAll("'",'&#39;');
const fail = message => { throw new Error(message); };
const required = (value, name, file) => typeof value === 'string' && value.trim() ? value.trim() : fail(`${file}: ${name} must be a nonempty string`);
const files = dir => fs.existsSync(dir) ? fs.readdirSync(dir).filter(f => f.endsWith('.json')).sort().map(f => `${dir}/${f}`) : [];
const monthLabel = new Intl.DateTimeFormat('en-US', {month:'long', year:'numeric', timeZone:'UTC'});
const read = (kind) => files(`${base}/${kind}`).map(file => {
  let item;
  try { item = JSON.parse(fs.readFileSync(file,'utf8')); } catch (e) { fail(`${file}: invalid JSON: ${e.message}`); }
  if (item.draft === true) return null;
  const slug = required(item.slug, 'slug', file);
  if (!/^[a-z0-9]+(?:-[a-z0-9]+)*$/.test(slug)) fail(`${file}: slug must use lowercase letters, numbers, and hyphens`);
  const title = required(item.title, 'title', file);
  const summary = required(item.summary, 'summary', file);
  const date = required(item.date, 'date', file);
  const monthOnly = kind === 'posts' && /^\d{4}-\d{2}$/.test(date);
  const isoDate = monthOnly ? `${date}-01` : date;
  const parsedDate = new Date(isoDate);
  if (!/^\d{4}-\d{2}-\d{2}$/.test(isoDate) || Number.isNaN(parsedDate.getTime()) || parsedDate.toISOString().slice(0,10) !== isoDate) fail(`${file}: date must be valid in ${kind === 'posts' ? 'YYYY-MM or YYYY-MM-DD' : 'YYYY-MM-DD'} format`);
  const displayDate = monthOnly ? monthLabel.format(parsedDate) : date;
  if (!Array.isArray(item.body) || !item.body.length) fail(`${file}: body must contain at least one block`);
  if (kind === 'posts' && !['research','firmware','fun','others'].includes(item.category)) fail(`${file}: category must be research, firmware, fun, or others`);
  return {...item, slug, title, summary, date, displayDate, file, kind};
}).filter(Boolean);
const uploads = `${base}/uploads`;
function media(name, file, kind = 'image') {
  if (!name) return '';
  const pattern = kind === 'video'
    ? /^[a-zA-Z0-9][a-zA-Z0-9._-]*\.mp4$/i
    : /^[a-zA-Z0-9][a-zA-Z0-9._-]*\.(?:png|jpe?g|gif|webp)$/i;
  if (typeof name !== 'string' || !pattern.test(name)) fail(`${file}: invalid ${kind} filename in ${uploads}: ${name}`);
  const source = `${uploads}/${name}`;
  if (!fs.existsSync(source)) fail(`${file}: ${kind} not found: ${source}`);
  fs.mkdirSync('site/assets/managed',{recursive:true});
  fs.copyFileSync(source, `site/assets/managed/${name}`);
  return `/assets/managed/${name}`;
}
const caption = block => block.caption ? `<figcaption>${html(block.caption)}</figcaption>` : '';
function blocks(item) {
  return item.body.map((block,i) => {
    const context = `${item.file}: body block ${i+1}`;
    if (!block || typeof block !== 'object') fail(`${context}: expected an object`);
    if (block.type === 'paragraph') return `<p>${html(required(block.text,'text',context))}</p>`;
    if (block.type === 'heading') return `<h2>${html(required(block.text,'text',context))}</h2>`;
    if (block.type === 'image') {
      const src = media(required(block.file,'file',context),context);
      const alt = required(block.alt,'alt',context);
      return `<figure><img src="${src}" alt="${html(alt)}" loading="lazy">${caption(block)}</figure>`;
    }
    if (block.type === 'video') {
      const src = media(required(block.file,'file',context),context,'video');
      const label = html(required(block.label,'label',context));
      const poster = media(block.poster,context);
      return `<figure><video src="${src}"${poster ? ` poster="${poster}"` : ''} aria-label="${label}" controls playsinline preload="metadata" style="display:block;width:100%"></video>${caption(block)}</figure>`;
    }
    if (block.type === 'list') {
      if (!Array.isArray(block.items) || !block.items.length) fail(`${context}: list must contain at least one item`);
      const tag = block.ordered ? 'ol' : 'ul';
      const marker = block.ordered ? 'decimal' : 'disc';
      const entries = block.items.map((entry,index) => {
        const text = html(required(entry?.text,'text',`${context}, list item ${index+1}`));
        const label = entry.label ? `<strong>${html(entry.label)}</strong> ` : '';
        return `<li style="list-style:inherit">${label}${text}</li>`;
      });
      return `<${tag} style="list-style:${marker} outside;margin:0 0 1.25em;padding-inline-start:1.5em">${entries.join('')}</${tag}>`;
    }
    if (block.type === 'link') {
      const url = required(block.url,'url',context);
      if (!/^https?:\/\//i.test(url)) fail(`${context}: link must start with https:// or http://`);
      return `<p><a href="${html(url)}">${html(required(block.text,'text',context))}</a></p>`;
    }
    fail(`${context}: type must be paragraph, heading, image, video, list, or link`);
  }).join('\n');
}
const posts = read('posts');
const projects = read('portfolio');
const seen = new Set();
for (const item of [...posts,...projects]) {
  const prefix = item.kind === 'posts' ? 'post' : 'portfolio-collections/my-portfolio';
  const url = `/${prefix}/${item.slug}/`;
  if (seen.has(url)) fail(`${item.file}: duplicate slug ${item.slug}`);
  seen.add(url);
  if (item.kind === 'portfolio' && !item.cover) fail(`${item.file}: portfolio items require a cover image`);
  const cover = media(item.cover,item.file);
  const content = blocks(item);
  for (const root of ['site','site/_mobile']) {
    const destination = `${root}${url}index.html`;
    if (fs.existsSync(destination) && !fs.readFileSync(destination,'utf8').includes('<!-- managed-content-page -->')) fail(`${item.file}: ${destination} already exists; refusing to overwrite an existing page`);
    let page = fs.readFileSync(`${base}/templates/${root.endsWith('_mobile') ? 'mobile' : 'desktop'}.html`,'utf8');
    const title = `${item.title} | Yixuan Song`;
    page = page.replace(/<title>[^<]*<\/title>/, `<title>${html(title)}</title>`)
      .replace('https://yixuan-siren.github.io/post/first-research-cruise/', `https://yixuan-siren.github.io${url}`);
    if (item.kind === 'portfolio') {
      page = page.replace(/(<div\b[^>]*\bdata-hook="blog-desktop-header-container"|<div class="NxBZ1a")>/,'$1 hidden>');
    }
    const back = item.kind === 'posts' ? ['/research-blog/','Research &amp; Updates'] : ['/portfolio/','Portfolio'];
    const language = item.lang ? ` lang="${html(item.lang)}"` : '';
    const article = `<!-- managed-content-page --><article class="cruise-blog-post" data-hook="post"${language}><a class="cruise-blog-back" href="${back[0]}">${back[1]}</a><h1>${html(item.title)}</h1><p class="cruise-blog-date">Yixuan Song · ${html(item.displayDate)}</p>${content}</article>`;
    const match = page.match(/<article class="cruise-blog-post"[\s\S]*?<\/article>/);
    if (!match) fail(`Cannot find article template in ${root}`);
    page = page.replace(match[0],() => article);
    fs.mkdirSync(path.dirname(destination),{recursive:true});
    fs.writeFileSync(destination,page);
  }
  item.url = url; item.coverUrl = cover;
}
function insert(file, selector, markup) {
  let source = fs.readFileSync(file,'utf8');
  source = source.replace(/<!-- managed-content-start -->[\s\S]*?<!-- managed-content-end -->/g,'');
  const {document} = parseHTML(source);
  const element = document.querySelector(selector);
  if (!element) fail(`Missing ${selector} in ${file}`);
  const opening = element.outerHTML.slice(0, element.outerHTML.indexOf('>')+1);
  if (!source.includes(opening)) fail(`Cannot locate insertion point in ${file}`);
  if (markup) source = source.replace(opening, () => `${opening}<!-- managed-content-start -->${markup}<!-- managed-content-end -->`);
  fs.writeFileSync(file,source);
}
const ordered = items => [...items].sort((a,b) => b.date.localeCompare(a.date) || a.title.localeCompare(b.title));
const blogCards = ordered(posts).map(p => `<article class="blog-directory-card${p.coverUrl?'':' blog-directory-card--text'}" data-hook="post" data-blog-category="${p.category}"><a href="${p.url}">${p.coverUrl?`<img src="${p.coverUrl}" alt="${html(p.coverAlt || p.title)}" loading="lazy">`:''}<div class="blog-directory-copy"><span class="blog-directory-year">${html(p.displayDate)}</span><h2>${html(p.title)}</h2><p>${html(p.summary)}</p><span class="blog-directory-more">Read the update</span></div></a></article>`).join('');
const projectCards = ordered(projects).map(p => `<a class="item-link-wrapper" href="${p.url}" aria-label="${html(p.title)}"><div class="gallery-item-container"><div class="gallery-item-wrapper"><div class="gallery-item-content"><img src="${p.coverUrl}" alt="${html(p.coverAlt || p.title)}" style="width:100%;height:100%;object-fit:cover" loading="lazy"></div></div></div></a>`).join('');
for (const root of ['site','site/_mobile']) {
  insert(`${root}/research-blog/index.html`,'.blog-directory',blogCards);
  insert(`${root}/portfolio/index.html`,'.pro-gallery-margin-container',projectCards);
}

// Read the published post cards after inserting managed entries, so every build refreshes both galleries.
const desktopBlog = parseHTML(fs.readFileSync('site/research-blog/index.html','utf8')).document;
const galleryImages = new Map();
for (const card of desktopBlog.querySelectorAll('.blog-directory-card')) {
  const title = card.querySelector('h2').textContent;
  const url = card.querySelector('a').getAttribute('href');
  const post = parseHTML(fs.readFileSync(`site${url}index.html`,'utf8')).document;
  const postImages = post.querySelectorAll('figure img, .cruise-blog-post img, [data-hook="post-content"] img');
  for (const image of [...card.querySelectorAll('img'), ...postImages]) {
    const src = image.getAttribute('src');
    if (src && !galleryImages.has(src)) galleryImages.set(src, image.getAttribute('alt') || title);
  }
}
const gallery = galleryImages.size ? `
  <div class="blog-photo-controls" hidden>
    <button type="button" data-photo-direction="-1" aria-controls="blog-photo-strip" aria-label="Scroll photos left">‹</button>
    <button type="button" data-photo-direction="1" aria-controls="blog-photo-strip" aria-label="Scroll photos right">›</button>
  </div>
  <div class="blog-photo-strip" id="blog-photo-strip" tabindex="0" role="group" aria-label="Scrollable photo gallery">
    ${[...galleryImages].map(([src, alt]) => `<img src="${html(src)}" alt="${html(alt)}" loading="lazy" decoding="async" draggable="false">`).join('\n    ')}
  </div>
` : '';
for (const root of ['site','site/_mobile']) {
  const file = `${root}/research-blog/index.html`;
  const source = fs.readFileSync(file,'utf8');
  const slot = /<section class="blog-photo-gallery"[^>]*>[\s\S]*?<\/section>/;
  if (!slot.test(source)) fail(`Missing photo gallery in ${file}`);
  const section = gallery
    ? `<section class="blog-photo-gallery" aria-label="Post photos">${gallery}</section>`
    : '<section class="blog-photo-gallery" hidden></section>';
  fs.writeFileSync(file,source.replace(slot,() => section));
}
console.log(`Built ${posts.length} Research & Updates posts and ${projects.length} portfolio projects. Updated both blog galleries with ${galleryImages.size} images.`);
