import fs from 'node:fs';
import path from 'node:path';
import {execFileSync} from 'node:child_process';
const git=process.env.WEBSITE_GIT_BIN||'/Applications/Xcode.app/Contents/Developer/usr/bin/git';
const files=execFileSync(git,['ls-files','-z'],{encoding:'utf8'}).split('\0').filter(file=>file&&!/^migration-part-\d+\.zip$/.test(file)&&fs.existsSync(file));
for (const file of ['site/post/first-research-cruise/index.html','site/_mobile/post/first-research-cruise/index.html','site/post/remembering-tom/index.html','site/_mobile/post/remembering-tom/index.html','site/post/minion-firmware-updates/index.html','site/_mobile/post/minion-firmware-updates/index.html']) if (!files.includes(file)) files.push(file);
for (const name of fs.readdirSync('site/assets/first-research-cruise')) { const file = 'site/assets/first-research-cruise/' + name; if (!files.includes(file)) files.push(file); }
for (const entry of JSON.parse(fs.readFileSync('content/blog/research-papers.json', 'utf8'))) for (const root of ['site', 'site/_mobile']) { const file = `${root}/post/${entry.slug}/index.html`; if (!files.includes(file)) files.push(file); }
for (const name of fs.readdirSync('site/documents/papers')) { const file = 'site/documents/papers/' + name; if (!files.includes(file)) files.push(file); }
for (const file of ['content/blog/research-papers.json', 'content/blog/minion-firmware.json']) if (fs.existsSync(file) && !files.includes(file)) files.push(file);
const groups=[[]];let size=0;
for(const file of files){const n=fs.statSync(file).size;if(size+n>15*1024*1024&&groups.at(-1).length){groups.push([]);size=0;}groups.at(-1).push(file);size+=n;}
const dir=path.resolve('review/upload');fs.mkdirSync(dir,{recursive:true});
for(const name of fs.readdirSync(dir))if(/^migration-part-\d+\.zip$/.test(name))fs.unlinkSync(path.join(dir,name));
for(let i=0;i<groups.length;i++){
  const out=path.join(dir,`migration-part-${i+1}.zip`);execFileSync('/usr/bin/zip',['-q',out,...groups[i]]);
  console.log(`${path.basename(out)}: ${groups[i].length} files, ${(fs.statSync(out).size/1048576).toFixed(1)} MiB`);
}
fs.copyFileSync('README.md',path.join(dir,'README.md'));
console.log('Source packages and README prepared in '+dir);
