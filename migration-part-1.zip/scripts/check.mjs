import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import {parseHTML} from 'linkedom';
const manifest=JSON.parse(fs.readFileSync('migration/manifest.json','utf8'));
assert.equal(manifest.failures.length,0,'Asset downloads must succeed');
let checked=0;const errors=[];
function checkLocal(url,base,context){
  if(!url||/^(?:https?:|mailto:|data:|#|tel:)/.test(url))return;
  const resolved=new URL(url,'https://local.test'+base);let file=path.join('site',decodeURIComponent(resolved.pathname));
  if(resolved.pathname.endsWith('/'))file=path.join(file,'index.html');
  if(!fs.existsSync(file)){errors.push(`${context}: missing ${file}`);return;}
  if(resolved.hash&&file.endsWith('.html')){
    const {document:d}=parseHTML(fs.readFileSync(file,'utf8'));
    if(!d.getElementById(decodeURIComponent(resolved.hash.slice(1))))errors.push(`${context}: missing anchor ${resolved.hash}`);
  }
  checked++;
}
for(const page of manifest.pages)for(const mobile of [false,true]){
  const route=page.route;const file=path.join('site',mobile?'_mobile':'',route,'index.html');
  const {document:d}=parseHTML(fs.readFileSync(file,'utf8'));
  assert(d.querySelector('title')?.textContent,`Title required: ${file}`);
  assert(d.querySelector('#contact'),`Contact anchor required: ${file}`);
  for(const el of d.querySelectorAll('[href],[src],[poster]')){
    for(const attr of ['href','src','poster'])if(el.hasAttribute(attr)){
      const url=el.getAttribute(attr);
      if(attr!=='href'&&/^https?:/.test(url))errors.push(`${file}: external ${attr} ${url}`);
      checkLocal(url,route,file);
    }
  }
  for(const el of d.querySelectorAll('[srcset],[srcSet]'))errors.push(`${file}: unresolved srcset`);
  for(const s of d.querySelectorAll('script'))if(s.getAttribute('src')!=='/site.js')errors.push(`${file}: unexpected script`);
  const css=[...d.querySelectorAll('style,[style]')].map(el=>el.tagName==='STYLE'?el.textContent:el.getAttribute('style')).join('\n');
  for(const match of css.matchAll(/url\(['"]?([^)'"\s]+)['"]?\)/g))checkLocal(match[1],route,file);
}
for(const asset of manifest.assets){
  const file='site/assets/'+asset.file;assert(fs.statSync(file).size>0,`Empty asset ${file}`);
  if(file.endsWith('.pdf'))assert(fs.readFileSync(file).subarray(0,4).toString()==='%PDF','Invalid PDF');
}
for(const doc of manifest.documents||[]){const file=path.join('site',doc.file);assert(fs.readFileSync(file).subarray(0,4).toString()==='%PDF',`Invalid PDF ${file}`);}
if(errors.length){console.error(errors.join('\n'));process.exit(1)}
console.log(`Passed: ${manifest.pages.length} desktop pages, ${manifest.pages.length} mobile layouts, ${manifest.assets.length} assets, ${checked} internal references.`);
