import fs from 'node:fs';
import path from 'node:path';
import {createHash} from 'node:crypto';
const hash=file=>createHash('sha256').update(fs.readFileSync(file)).digest('hex').slice(0,12);
const cssVersion=hash('site/migration.css');
const jsVersion=hash('site/site.js');
function htmlFiles(dir){return fs.readdirSync(dir,{withFileTypes:true}).flatMap(e=>e.isDirectory()?htmlFiles(path.join(dir,e.name)):e.name.endsWith('.html')?[path.join(dir,e.name)]:[]);}
let changed=0;
for(const file of htmlFiles('site')){
  const before=fs.readFileSync(file,'utf8');
  const after=before
    .replace(/(<link\b[^>]*\bhref=["'])\/migration\.css(?:\?[^"']*)?(["'])/g,`$1/migration.css?v=${cssVersion}$2`)
    .replace(/(<script\b[^>]*\bsrc=["'])\/site\.js(?:\?[^"']*)?(["'])/g,`$1/site.js?v=${jsVersion}$2`);
  if(after!==before){fs.writeFileSync(file,after);changed++;}
}
console.log(`Versioned CSS ${cssVersion} and JS ${jsVersion}; ${changed} pages updated.`);
