import fs from 'node:fs';
import {parseHTML} from 'linkedom';
const data=JSON.parse(fs.readFileSync('content/about.json','utf8'));
const escape=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
for(const file of ['site/about/index.html','site/_mobile/about/index.html']){
  const {document:d}=parseHTML(fs.readFileSync(file,'utf8'));
  d.querySelector('#comp-kgs2c0cr h2').textContent='Awards';
  d.getElementById('comp-kgs1op2v').innerHTML=`<ul class="about-awards">${data.awards.map(a=>`<li><span class="award-year">${escape(a.year)}</span><div><strong>${escape(a.title)}</strong><br>${escape(a.organization)}</div></li>`).join('')}</ul>`;
  const html=d.documentElement.outerHTML.replace(/(<style\b[^>]*>)([\s\S]*?)(<\/style>)/gi,(_,open,css,close)=>open+css.replace(/&(?:amp;)*quot;/g,'"')+close);
  fs.writeFileSync(file,'<!doctype html>\n'+html);
}
console.log(`Updated About with ${data.awards.length} awards from the current CV.`);
