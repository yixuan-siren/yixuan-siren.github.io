import fs from 'node:fs';
import path from 'node:path';
import {execFileSync} from 'node:child_process';
const sourceDir=process.argv[2];
if(!sourceDir)throw Error('Usage: node scripts/build-public-cv.mjs /absolute/path/to/CV');
const config=JSON.parse(fs.readFileSync('content/cv.json','utf8'));
const buildDir=path.resolve('review/cv-build');fs.mkdirSync(buildDir,{recursive:true});
let tex=fs.readFileSync(path.join(sourceDir,'cv.tex'),'utf8');
function replaceOnce(pattern,replacement,label){
  const before=tex;tex=tex.replace(pattern,replacement);if(tex===before)throw Error('Expected source section missing: '+label);
}
if(config.omitPersonalPhone)replaceOnce(/\\address\{\+[^\n]*?\\hfill ([^\n]*?)\}/,'\\address{\\hfill $1}','personal phone');
if(config.omitGrantsAndFunding)replaceOnce(/\\begin\{rSection\}\{Research Grants and Funding\}[\s\S]*?\\end\{rSection\}/i,'','grants and funding');
if(config.omitReferences)replaceOnce(/\\newpage\s*\\begin\{rSection\}\{References\}[\s\S]*?\\end\{rSection\}/,'','references');
replaceOnce('Diel Dynamics of Zooplankton Fecal Pellet Flux Revealed by Integrated Optical Observations and Modeling.','Diel Dynamics of Zooplankton Fecal Pellet Flux Revealed by Integrated in situ Imaging Observations and Modeling.','published title');
replaceOnce('K. Ziervogel, K. Sweet, \\textbf{Y. Song}, J. Bretherton, M. Rau, A. Quigg, U. Passow (2024).','K. Ziervogel, J. A. Sweet, \\textbf{Y. Song}, L. Bretherton, M. Rau, A. Quigg, U. Passow (2025).','published author initials and issue year');
tex=tex.replace('\\begin{document}','\\hypersetup{pdftitle={Yixuan Song - Curriculum Vitae},pdfauthor={Yixuan Song}}\n\\begin{document}');
tex=tex.replace('\\usepackage{enumitem}','\\usepackage{enumitem}\n\\usepackage{needspace}');
tex=tex.replace('\\begin{rSection}{Professional Memberships}','\\Needspace{7\\baselineskip}\n\\begin{rSection}{Professional Memberships}');
fs.writeFileSync(path.join(buildDir,'cv-public.tex'),tex);
fs.copyFileSync(path.join(sourceDir,'resume.cls'),path.join(buildDir,'resume.cls'));
const latex=process.env.CV_LATEX_BIN||'/Library/TeX/texbin/pdflatex';
for(let i=0;i<2;i++)execFileSync(latex,['-no-shell-escape','-interaction=nonstopmode','-halt-on-error','cv-public.tex'],{cwd:buildDir,stdio:'pipe'});
for(const dir of ['site/documents','素材库/02_网站版本/文档']){
  fs.mkdirSync(dir,{recursive:true});fs.copyFileSync(path.join(buildDir,'cv-public.pdf'),path.join(dir,'Yixuan-Song-CV.pdf'));
}
console.log('Created public CV; master CV files unchanged.');
