import fs from 'node:fs';
const manifest=JSON.parse(fs.readFileSync('migration/manifest.json','utf8'));
const names=['home','about','publications','research-blog','portfolio','post','category','tag-3d','tag-surprise','project-1','project-3','project-5','project-6'];
const queue=manifest.pages.map((p,i)=>({...p,name:names[i]}));
fs.mkdirSync('migration/source/mobile',{recursive:true});
await Promise.all(Array.from({length:4},async()=>{
  while(queue.length){const p=queue.shift();const local=`migration/source/mobile/wix-${p.name}.html`;if(fs.existsSync(local))continue;
    const res=await fetch(p.source,{headers:{'User-Agent':'Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Mobile/15E148 Safari/604.1'},signal:AbortSignal.timeout(60000)});
    if(!res.ok)throw Error(`${p.name}: HTTP ${res.status}`);
    fs.writeFileSync(local,await res.text());console.log('Saved mobile '+p.name);
  }
}));
