import fs from 'node:fs';
import path from 'node:path';
import {parseHTML} from 'linkedom';
const data=JSON.parse(fs.readFileSync('content/home.json','utf8'));
const escape=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const profileItems=data.profiles.map(p=>`<li><a href="${escape(p.url)}" aria-label="${escape(p.label)}" title="${escape(p.label)}" target="_blank" rel="noopener noreferrer"><img src="${escape(p.icon)}" alt="${escape(p.label)}" width="30" height="30" decoding="async"></a></li>`).join('');
const list=`<ul aria-label="Academic profiles">${profileItems}</ul>`;
function htmlFiles(dir){return fs.readdirSync(dir,{withFileTypes:true}).flatMap(e=>e.isDirectory()?htmlFiles(path.join(dir,e.name)):e.name.endsWith('.html')?[path.join(dir,e.name)]:[]);}
for(const file of htmlFiles('site')){
  const {document:d}=parseHTML(fs.readFileSync(file,'utf8').replaceAll('yixuan.song@uri.edu',data.contactEmail).replaceAll('ee-shuan','yi-shuan').replaceAll('pronounces like yi-shuan','pronounced yi-shuan'));
  const footer=d.getElementById('comp-kgtcrh5e');
  if(footer){
    const weibo=footer.querySelector('a[href*="weibo.com"]')?.closest('li')?.outerHTML||'';
    footer.classList.add('profile-links');footer.innerHTML=`<ul aria-label="Academic and social profiles">${profileItems}${weibo}</ul>`;
  }
  if(file==='site/index.html'||file==='site/_mobile/index.html'){
    for(const [id,text] of [['comp-kgrz2nkn',data.introduction],['comp-kgrz2xr0',data.researchInterests]]){
      const el=d.getElementById(id);const span=[...el.querySelectorAll('span')].at(-1);span.textContent=text;
    }
    const hero=d.getElementById('comp-kgrynnet');
    if(hero){hero.classList.add('profile-links');hero.innerHTML=list;}
    else{
      d.querySelector('.home-mobile-profiles')?.remove();
      const links=d.createElement('div');links.className='profile-links home-mobile-profiles';links.innerHTML=list;d.getElementById('comp-kgrz2nkn').append(links);
    }
    d.title='Yixuan Song | Ocean Imaging and Experimental Fluid Mechanics';
    const description='Yixuan Song studies ocean particles and carbon transport through experimental fluid mechanics, quantitative underwater imaging, and autonomous ocean observations.';
    d.querySelector('meta[name="description"]')?.setAttribute('content',description);
  }
  const html=d.documentElement.outerHTML.replace(/(<style\b[^>]*>)([\s\S]*?)(<\/style>)/gi,(_,open,css,close)=>open+css.replace(/&(?:amp;)*quot;/g,'"')+close);
  fs.writeFileSync(file,'<!doctype html>\n'+html);
}
const jsFile='site/site.js';fs.writeFileSync(jsFile,fs.readFileSync(jsFile,'utf8').replaceAll('yixuan.song@uri.edu',data.contactEmail));
const manifest=JSON.parse(fs.readFileSync('migration/manifest.json','utf8'));
for(const icon of ['google-scholar','orcid'])if(!manifest.assets.some(a=>a.file===icon+'.svg'))manifest.assets.push({url:`https://raw.githubusercontent.com/simple-icons/simple-icons/develop/icons/${icon.replace('-','')}.svg`,file:icon+'.svg'});
fs.writeFileSync('migration/manifest.json',JSON.stringify(manifest,null,2));
console.log('Updated home introduction, academic profile icons, and website contact email.');
